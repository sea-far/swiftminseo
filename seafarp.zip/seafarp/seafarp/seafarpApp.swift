//
//  seafarpApp.swift
//  seafarp
//
//  Created by 지니 on 8/14/24.
//

import SwiftUI

@main
struct seafarpApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
